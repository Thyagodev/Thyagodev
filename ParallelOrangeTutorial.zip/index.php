<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
</head>
<body>
  <form action="uploads.php" method="POST" enctype="multipart/form-data">

  arquivo:<br><input type="file" name="arquivo"><br>
  
  <button type="submit" name="enviar">ENVIAR</button>

</body>

</html>


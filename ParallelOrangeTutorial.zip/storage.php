<!doctype HTML>
<html>
<head>
<meta charset="utf-8">
</head>
<body>

  <?php 
    
    if (isset($_POST['enviar'])):
    
    /////////////  Declaração de variáveis  /////////////
    $erros= array();
    $idade = $_POST['idade'];
    $email = $_POST['email'];
    

    ///////////// Sanitizar e Filtrar ///////////////////

$idade = filter_input(INPUT_POST, 'idade', FILTER_SANITIZE_NUMBER_INT);
    if(!filter_var($idade, FILTER_VALIDATE_INT)):
      $erros[] = "Idade inválida";
      endif;
    
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);

    if(!filter_var($email, FILTER_SANITIZE_EMAIL)):
      $erros[]="Email inválido";
    endif;

    if(!$peso = filter_input(INPUT_POST,'peso',FILTER_VALIDATE_INT)):
      $erros[]="Peso inválido";

    endif;

///////////////////  Mostrar erros  /////////////////////    
    if (!empty($erros)):
      foreach($erros as $erro):
        echo"<li>$erro</li>";
      endforeach;

    else:
      echo"Formulário aceito<br>";
    endif;
    

//////////////////////////////////////////////////////////
  ?>

  <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">

    Idade:<br><input type="text" name="idade"><br>

    Email:<br> <input type="text" name="email"><br>

    <button type="submit" name="enviar">ENVIAR</button>

  </form>
</body>


</html>

<?php
  $num1 = 10;
  $num2 = 20;

  function somar(){
    $somavale = $GLOBALS['num1'] + $GLOBALS['num2'];
    echo $_SERVER['SERVER_NAME'];
  }
  somar();
?>